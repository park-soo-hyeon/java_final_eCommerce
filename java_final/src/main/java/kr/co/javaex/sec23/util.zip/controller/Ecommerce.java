package kr.co.javaex.sec23.controller;

import java.util.Scanner;

public class Ecommerce {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UserController userController = new UserController();
        ProductController productController = new ProductController();

        boolean isRunning = true;

        while (isRunning) {
            System.out.println("\n===== [ e-Commerce 메인 시스템 ] =====");
            System.out.println("1. 회원 서비스");
            System.out.println("2. 상품 관리 (관리자 전용)");
            System.out.println("0. 프로그램 종료");
            System.out.print("메뉴 선택: ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    // 사용자가 1번을 누르면 회원 관리 전용 메뉴판을 통째로 띄워줍니다!
                    userController.userMenu();
                    break;
                case "2":
                    // 사용자가 2번을 누르면 상품 관리 전용 메뉴판을 통째로 띄워줍니다!
                    // (이때 로그인이 되어있는지, 관리자인지 체크하는 로직을 controller에 추가하면 완벽합니다)
                    //productController.productMenu();
                    break;
                case "0":
                    System.out.println("시스템을 종료합니다.");
                    isRunning = false;
                    break;
                default:
                    System.out.println("잘못된 입력입니다.");
            }
        }
        scanner.close();
    }
}