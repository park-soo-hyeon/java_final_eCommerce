package kr.co.javaex.sec23.domain;

public class User {
    private String userId;
    private String name;
    private String userPw;
    private String userNum;
    private String userEmail;
    private String userStatus;
    private String userCate;

    public User() {}

    public User(String userId, String name, String userPw, String userNum, String userEmail, String userStatus, String userCate) {
        this.userId = userId;
        this.name = name;
        this.userPw = userPw;
        this.userNum = userNum;
        this.userEmail = userEmail;
        this.userStatus = userStatus;
        this.userCate = userCate;
    }

    public User(String userId, String name, String userPw, String userNum, String userEmail, String userCate) {
        this.userId = userId;
        this.name = name;
        this.userPw = userPw;
        this.userNum = userNum;
        this.userEmail = userEmail;
        this.userStatus = "정상";
        this.userCate = userCate;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUserPw() {
        return userPw;
    }

    public void setUserPw(String userPw) {
        this.userPw = userPw;
    }

    public String getUserNum() {
        return userNum;
    }

    public void setUserNum(String userNum) {
        this.userNum = userNum;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserStatus() {
        return userStatus;
    }

    public void setUserStatus(String userStatus) {
        this.userStatus = userStatus;
    }

    public String getUserCate() {
        return userCate;
    }

    public void setUserCate(String userCate) {
        this.userCate = userCate;
    }
}
